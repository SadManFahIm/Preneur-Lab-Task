<?php

	function DBconnection(){
		$conn= mysqli_connect('localhost', 'id12500882_fahim', 'Abcd1234', 'id12500882_demo');
		return $conn;
	}
	

?>